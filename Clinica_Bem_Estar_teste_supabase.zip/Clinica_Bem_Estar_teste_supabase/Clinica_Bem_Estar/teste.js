import { supabase } from './supabase.js'
 
async function testarConexao() {
  const { data, error } = await supabase
    .from('profissionais')
    .select('*')
 
  if (error) {
    console.error('Erro:', error.message)
    return
  }
 
  console.log('Profissionais cadastrados:', data)
}
 
testarConexao()